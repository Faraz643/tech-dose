export const authoriseIsAdmin = (req, res) => {
  res.json({ status: "Is admin" });
};
